You can use this dll as it is or with python.
To use with python, change .dll extension to .pyd!